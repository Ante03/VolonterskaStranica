import { useState, useEffect } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import { Link } from 'react-router-dom';
import TablicaUdruge from './components/TablicaUdruge';
import UnosFormaUdruge from './components/UnosFormaUdruge';
import axios from "axios";

function App() {
  const [isAdmin, setIsAdmin] = useState(false);
  const [udruge, postaviUdruge] = useState([]);

  const ChangeInAdmin = () => {
    setIsAdmin(!isAdmin);
  };
  useEffect(() => {
    axios
      .get("http://localhost:3001/udruge")
      .then(res => postaviUdruge(res.data));
  }, []);

  return (
    <div id='sve'>
          <div className='HomePageDiv' id='HomePageHeader'>
            <Link to="/">Pocetna</Link><br />
            <Link to="/volonteri">Volonteri</Link><br />
            <Link to="/aktivnosti">Aktivnosti</Link><br />
            <Link to="/udruge">Udruge</Link><br />
            <label>
              <input type='checkbox' checked={isAdmin} onChange={ChangeInAdmin}></input>
              Admin
            </label>
          </div >
          <hr></hr>
          <div id="Aktivnosti">
            <h2>Popis udruga</h2>
            <TablicaUdruge udruge={udruge} postaviPodatke={postaviUdruge} isAdmin={isAdmin}/>
          </div>
          <div id="Aktivnosti">
            <UnosFormaUdruge dodaj= {postaviUdruge} admin={isAdmin}/>
          </div>
    </div>

  )
}

export default App

