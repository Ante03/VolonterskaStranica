import { useState, useEffect } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import { Link } from 'react-router-dom';
import UnosFormaVolonter from './components/UnosFormaVolonter';
import TablicaVolonter from './components/TablicaVolonter'
import axios from "axios";

function App() {
  const [isAdmin, setIsAdmin] = useState(false);
  const [volonteri, postaviVolonteri] = useState([]);
  const [prikaz, setPrikaz] = useState("sve");


  const ChangeInAdmin = () => {
    setIsAdmin(!isAdmin);
  };
  useEffect(() => {
    axios
      .get("http://localhost:3001/volonter")
      .then(res => postaviVolonteri(res.data));
  }, []);
  const handleOptionChange = (event ) => {
    setPrikaz(event.target.value);
  };

  return (
    <div id='sve'>
          <div className='HomePageDiv' id='HomePageHeader'>
            <Link to="/">Pocetna</Link><br />
            <Link to="/volonteri">Volonteri</Link><br />
            <Link to="/aktivnosti">Aktivnosti</Link><br />
            <Link to="/udruge">Udruge</Link><br />
            <label>
              <input type='checkbox' checked={isAdmin} onChange={ChangeInAdmin}></input>
              Admin
            </label>
          </div>
          <div id="odabirPrikaza">
              <div>
                  <input
                    className="prikazRadio"
                    type="radio"
                    id="sve"
                    name="volonteri"
                    value="sve"
                    checked={prikaz === "sve"}
                    onChange={handleOptionChange}
                  />
                  <label htmlFor="sve">Sve</label>
                </div>
                <div>
                  <input
                    className="prikazRadio"
                    type="radio"
                    id="zaposlen"
                    name="volonteri"
                    value="zaposlen"
                    checked={prikaz === "zaposlen"}
                    onChange={handleOptionChange}
                  />
                  <label htmlFor="zaposlen">Zaposlen</label>
                </div>
                <div>
                  <input
                    className="prikazRadio"
                    type="radio"
                    id="nezaposlen"
                    name="volonteri"
                    value="nezaposlen"
                    checked={prikaz === "nezaposlen"}
                    onChange={handleOptionChange}
                  />
                  <label htmlFor="nezaposlen">Nezaposlen</label>
                </div>
                <div>
                  <input
                    className="prikazRadio"
                    type="radio"
                    id="student"
                    name="volonteri"
                    value="student"
                    checked={prikaz === "student"}
                    onChange={handleOptionChange}
                  />
                  <label htmlFor="student">Student</label>
                </div>
                <div>
                  <input
                    className="prikazRadio"
                    type="radio"
                    id="umirovljen"
                    name="volonteri"
                    value="umirovljen"
                    checked={prikaz === "umirovljen"}
                    onChange={handleOptionChange}
                  />
                  <label htmlFor="umirovljen">Umirovljen</label>
                </div>
          </div>
          <hr></hr>
          <div id="Aktivnosti">
                    <h2>Popis Volontera</h2>
                    <TablicaVolonter volonteri={volonteri}  prikaz={prikaz} isAdmin={isAdmin}/>
                  </div>
          <div id="Aktivnosti">
            {isAdmin && (
              <div>
                  <div>
                    <h1>Dodaj volontera</h1>
                    <UnosFormaVolonter dodaj={postaviVolonteri} />
                  </div>
              </div>
            )}
          </div>
    </div>

  )
}

export default App

