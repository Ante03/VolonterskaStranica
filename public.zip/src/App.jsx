import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import Pocetna from './Pocetna'
import Aktivnosti from './Aktivnosti'
import Volonteri from './Volonteri'
import Udruge from './Udruge'
import {
  BrowserRouter,
  Routes,
  Route,
} from "react-router-dom";


function App() {

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Pocetna />} />
        <Route path="/aktivnosti" element={<Aktivnosti />} />
        <Route path="/volonteri" element={<Volonteri />} />
        <Route path="/udruge" element={<Udruge />} />
      </Routes>
    </BrowserRouter>
  )
}

export default App
