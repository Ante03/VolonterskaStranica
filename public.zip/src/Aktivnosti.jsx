import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import { Link } from 'react-router-dom';
import axios from "axios";
import { useEffect } from "react";
import Tablica from "./components/Tablica";
import UnosForma from "./components/UnosForma.jsx";

function App() {
  const [isAdmin, setIsAdmin] = useState(false);
  const [aktivnosti, postaviAktivnosti] = useState([]);

  const ChangeInAdmin = () => {
    setIsAdmin(!isAdmin);
  };
  useEffect(() => {
    axios
      .get("http://localhost:3001/akcija")
      .then(res => postaviAktivnosti(res.data));
  }, []);

  return (
    <div id='sve'>
          <div className='HomePageDiv' id='AktivnostiHeader'>
            <Link to="/">Pocetna</Link><br />
            <Link to="/volonteri">Volonteri</Link><br />
            <Link to="/aktivnosti">Aktivnosti</Link><br />
            <Link to="/udruge">Udruge</Link><br />
            <label>
              <input type='checkbox' checked={isAdmin} onChange={ChangeInAdmin}></input>
              Admin
            </label>
          </div>
          <hr></hr>
          <div id="Aktivnosti">
            <h2>Popis Aktivnosti</h2>
            <Tablica aktivnosti={aktivnosti} promjena={postaviAktivnosti} isAdmin={isAdmin}/>
          </div>
          <div id="Aktivnosti">
            <h3>Dodaj aktivnost</h3>
            <UnosForma dodaj= {postaviAktivnosti}/>
          </div>
    </div>

  )
}

export default App


