import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import { Link } from 'react-router-dom';

function App() {
  const [isAdmin, setIsAdmin] = useState(false);

  const ChangeInAdmin = () => {
    setIsAdmin(!isAdmin);
  };

  return (
    <div id='sve'>
          <div className='HomePageDiv' id='HomePageHeader'>
            <Link to="/">Pocetna</Link><br />
            <Link to="/volonteri">Volonteri</Link><br />
            <Link to="/aktivnosti">Aktivnosti</Link><br />
            <Link to="/udruge">Udruge</Link><br />
            <label>
              <input type='checkbox' checked={isAdmin} onChange={ChangeInAdmin}></input>
              Admin
            </label>
          </div>
          <hr></hr>
          <div className='HomePageDivv' id="Aktivnosti">
            <h3>O stranici:</h3>
            <p>Volonterska stranica u Splitu pruža platformu za povezivanje zajednice s različitim 
              volonterskim prilikama diljem grada. Na ovoj platformi, ljudi mogu pronaći raznovrsne 
              radne akcije i volonterske projekte koji odgovaraju njihovim interesima i vještinama. 
              Kroz jednostavan proces registracije, pojedinci se mogu učlaniti kao volonteri te istražiti 
              dostupne mogućnosti volontiranja. Osim toga, stranica pruža informacije o trenutnim inicijativama, 
              događajima i projektima kojima se može pridružiti, kao i resurse i alate za poboljšanje volonterskog 
              iskustva. Svojim korisnicima omogućava da aktivno doprinose zajednici i ostvaruju pozitivan utjecaj 
              na svoje okruženje kroz volontiranje.</p>
          </div>
          <hr></hr>
          <div className='HomePageDivv' id="Aktivnosti">
              <h3>O nama:</h3>
              <p>Pozdrav, zovem se Ante Spajić i ja sam autor ove stranice. Student sam Računarstva na FESB-u, volim programirati,
                baviti se sportom i čitati. Nadam se da ti se sviđa moja stranica!
              </p>
              <a>Mail: spajica02@gmail.com</a><br />
              <a>Konatakt broj: +385 95 563 0839</a><br />
              <a href="https://www.linkedin.com/in/ante-spaji%C4%87-5551222ba/">Linkedin</a><br />
              <a href='https://github.com/Ante03'>GitHub</a><br />
          </div>
    </div>

  )
}

export default App

