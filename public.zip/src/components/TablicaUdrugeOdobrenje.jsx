import RedakTabliceUdrugeOdobrenje from "./RedakTabliceUdrugeOdobrenje";

function Tablica({ udruge, postaviPodatke, podaciCekanje, postaviPodatkeCekanje }) {
    return (
        <table>
            <thead>
                <tr>
                <th>Vrsta</th>
                <th>Datum</th>
                </tr>
            </thead>
            <tbody>
                {udruge.map(r => (
                <RedakTabliceUdrugeOdobrenje key={r.id} rez={r} dodaj={postaviPodatke} podaciCekanje={podaciCekanje} postaviPodatkeCekanje={postaviPodatkeCekanje}/>
                ))}
            </tbody>
        </table>
    );
}

export default Tablica;
