import { useState } from "react";
import axios from "axios";
import { v4 as uuidv4 } from 'uuid'; 

function RedakTabliceUdruge({ rez, postaviPodatke, podaciCekanje, postaviPodatkeCekanje }) {

    function obradiPodatke(objekt) {
        return {
          id: uuidv4(),
          ime: objekt.ime,
          adresa: objekt.adresa,
          grad: objekt.grad
        };
    }

    const saljiPodatke = event => {
        event.preventDefault();
        const zaSlanje = obradiPodatke(rez);
        
        axios.post('http://localhost:3001/udruge', zaSlanje)
        .then(rezz => {
            postaviPodatke((stanje) => [...stanje, rezz.data]);
        });
        postaviPodatkeCekanje(podaciCekanje.filter((zahtjev) => zahtjev.id !== rez.id));
        axios.delete(`http://localhost:3001/udrugecekanje/${rez.id}`);  
        postaviPodatkeCekanje((stanje) => stanje.filter((el) => el.id != rez.id));
    };

    const obrisiZahtjev = () => {
        postaviPodatkeCekanje(podaciCekanje.filter((zahtjev) => zahtjev.id !== rez.id));
        axios.delete(`http://localhost:3001/udrugecekanje/${rez.id}`);  
        postaviPodatkeCekanje((stanje) => stanje.filter((el) => el.id != rez.id));
    };

    return (
        <tr>
            <td>{rez.ime}</td>
            <td>{rez.adresa}</td>
            <td>{rez.grad}</td>
            <td><button onClick={saljiPodatke}>Dodaj</button></td>
            <td><button onClick={obrisiZahtjev}>Obriši zahtjev</button></td>
        </tr>
    );
}

export default RedakTabliceUdruge;
