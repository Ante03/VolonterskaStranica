import axios from "axios";

function Brisanje(props) {
    async function brisiPodatak() {
        const potvrda = window.confirm("Jeste li sigurni da želite obrisati volontera?");

        if (potvrda) {
            await axios.delete(`http://localhost:3001/volonter/${props.idvol}`);   
            props.promjena((stanje) => stanje.filter((el) => el.id != props.idvol));
        }
    }

    return (
        <div>
            <button onClick={brisiPodatak} id="brisiBut">Obriši volontera</button>
        </div>
    );
}

export default Brisanje;