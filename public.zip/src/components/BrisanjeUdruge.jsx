import axios from "axios";

function Brisanje(props) {
    async function brisiPodatak() {
        const potvrda = window.confirm("Jeste li sigurni da želite obrisati udrugu?");

        if (potvrda) {
            await axios.delete(`http://localhost:3001/udruge/${props.idudruga}`);  
            props.promjena((stanje) => stanje.filter((el) => el.id != props.idudruga));
        }
    }

    return (
        <div>
            <button onClick={brisiPodatak} id="brisiBut">Obriši udrugu</button>
        </div>
    );
}

export default Brisanje;