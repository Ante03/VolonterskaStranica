import { useState } from "react";
import axios from "axios";
import BrisanjeUdruge from './BrisanjeUdruge'

function RedakTabliceUdruge({ rez, postaviPodatke, isAdmin }) {
if(isAdmin===true){
    return (
        <tr>
            <td>{rez.ime}</td>
            <td>{rez.adresa}</td>
            <td>{rez.grad}</td>
            <td><BrisanjeUdruge promjena={postaviPodatke} idudruga={rez.id} /></td>
        </tr>
    );
}
else 
    return (
        <tr>
            <td>{rez.ime}</td>
            <td>{rez.adresa}</td>
            <td>{rez.grad}</td>
        </tr>
    );

}

export default RedakTabliceUdruge;