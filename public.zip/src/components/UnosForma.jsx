import { useState } from "react";
import axios from "axios";
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
 
function UnosForma( props ) {
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [formaPodaci, postaviPodatke] = useState({
    vrsta: "",
    mjesto: "",
    vrijeme: "",
    datum: "",
    opis:"",
    volonter:[{
      "ime":"",
      "prezime":"",
      "posao":""
    }]
  });

  const handleDateChange = date => {
    setSelectedDate(date);
  };

  function obradiPodatke(objekt){
  
      return {
        "vrsta" : objekt.vrsta,
        "mjesto": objekt.mjesto,
        "vrijeme": objekt.vrijeme,
        "datum": selectedDate.toDateString(),
        "opis":objekt.opis,
        "volonter":objekt.volonter
    }
    }
 
  const saljiPodatke = event => {
    event.preventDefault();
       
        const zaSlanje = obradiPodatke(formaPodaci)
        
        axios.post('http://localhost:3001/akcija', zaSlanje)
        .then(rez => {
            props.dodaj((stanje) => [...stanje, rez.data])
            console.log(rez.data);
        })
        setSelectedDate(new Date());
        postaviPodatke({
          vrsta: "",
          mjesto: "",
          vrijeme: "",
          datum: "",
          opis:"",
          volonter:[{
            "ime":"",
            "prezime":"",
            "posao":""
          }]
        });
  };
  function promjenaUlaza(event) {
    const { name, value } = event.target;
    postaviPodatke({ ...formaPodaci, [name]: value });
  }
 
  return (
    <form onSubmit={saljiPodatke}>
      <div>
        <label>
          Vrsta:
          <input
            type='text'
            name='vrsta'
            value={formaPodaci.vrsta}
            onChange={promjenaUlaza}
            required
          />
        </label>
      </div>
      <div>
        <label>
            Mjesto:
        <input type='text' name='mjesto' value={formaPodaci.mjesto}
            onChange={promjenaUlaza} required />
        </label>
        </div>
        <div>
            <label>
                Vrijeme:
            <input type='number' name='vrijeme' value={formaPodaci.vrijeme}
                onChange={promjenaUlaza} required/>
            </label>
        </div>
        <div>
        <DatePicker
            selected={selectedDate}
            onChange={handleDateChange}
            dateFormat="dd/MM/yyyy"
        />
        </div>
        <div>
            <label>
                Opis:
            <input type='text' name='opis' value={formaPodaci.opis}
                onChange={promjenaUlaza} required/>
            </label>
        </div>
      <button type='submit'>Nova aktivnost</button>
    </form>
  );
}
 
export default UnosForma;