
import TablicaUdruge from './TablicaUdruge';
import { useState, useEffect } from "react";
import axios from "axios";
import { v4 as uuidv4 } from 'uuid';
import TablicaUdrugeOdobrenje from './TablicaUdrugeOdobrenje'

function UnosForma(props) {
  const [podaciCekanje, postaviPodatkeCekanje] = useState([]);
  const [formaPodaci, postaviPodatke] = useState({
    ime: "",
    adresa: "",
    grad: ""
  });

  useEffect(() => {
    axios
      .get("http://localhost:3001/udrugecekanje")
      .then(res => postaviPodatkeCekanje(res.data));
  }, []);

  function obradiPodatke(objekt) {
    return {
      id: uuidv4(),
      ime: objekt.ime,
      adresa: objekt.adresa,
      grad: objekt.grad
    };
  }
    const saljiPodatke = event => {
        event.preventDefault();
        const zaSlanje = obradiPodatke(formaPodaci);
        
        axios.post('http://localhost:3001/udrugecekanje', zaSlanje)
        .then(rez => {
            postaviPodatkeCekanje((stanje) => [...stanje, rez.data]);
        });
        postaviPodatke({
          ime: "",
          adresa: "",
          grad: ""
        });
    };

  const DodajUdrugu = (event) => {
    event.preventDefault();

    const zaSlanje = obradiPodatke(formaPodaci);

    postaviPodatkeCekanje([...podaciCekanje, zaSlanje]);
    postaviPodatke({
      ime: "",
      adresa: "",
      grad: ""
    });
  };

  function promjenaUlaza(event) {
    const { name, value } = event.target;
    postaviPodatke({ ...formaPodaci, [name]: value });
  }
  if(props.admin===true){
    return (
      <div>
        <h3>Zahtjevi:</h3>
        <TablicaUdrugeOdobrenje udruge={podaciCekanje} postaviPodatke={props.dodaj} podaciCekanje={podaciCekanje} postaviPodatkeCekanje={postaviPodatkeCekanje}/>
      </div>
        );
  }
  else{
    return (
      <div>
      <h3>Dodaj udrugu</h3>
      <form onSubmit={DodajUdrugu}>
          <div>
            <label>
              Ime:
              <input
                type="text"
                name="ime"
                value={formaPodaci.ime}
                onChange={promjenaUlaza}
                required
              />
            </label>
          </div>
          <div>
            <label>
              Grad:
              <input
                type="text"
                name="grad"
                value={formaPodaci.grad}
                onChange={promjenaUlaza}
                required
              />
            </label>
          </div>
          <div>
            <label>
              Adresa:
              <input
                type="text"
                name="adresa"
                value={formaPodaci.adresa}
                onChange={promjenaUlaza}
                required
              />
            </label>
          </div>
          <button type="submit" onClick={saljiPodatke}>Nova udruga</button>
        </form>
      </div>
        );
  }
   

}

export default UnosForma;
