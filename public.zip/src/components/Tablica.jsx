import RedakTablice from "./RedakTablice";

function Tablica({ aktivnosti, promjena, isAdmin}) {
    return (
        <table>
            <thead>
                <tr>
                <th>Vrsta</th>
                <th>Datum</th>
                </tr>
            </thead>
            <tbody>
                {aktivnosti.map(r => (
                <RedakTablice key={r.id} rez={r} promjena={promjena} idaktivnost={r.id} isAdmin={isAdmin}/>
                ))}
            </tbody>
        </table>
    );
}

export default Tablica;
