import { useState } from "react";
import axios from "axios";
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
 
function UnosFormaVolonter( props ) {
  const [formaPodaci, postaviPodatke] = useState({
    ime: "",
    prezime: "",
    zanimanje: "",
    grad:""
  });
  const zanimanja = ["student", "zaposlen", "nezaposlen", "umirovljen"];
  const grad = ["Zagreb", "Split", "Rijeka", "Osijek", "Zadar", "Dubrovik", "Sibenik", "Pula"];

  function obradiPodatke(objekt){
  
      return {
        "ime" : objekt.ime,
        "prezime": objekt.prezime,
        "grad": objekt.grad,
        "zanimanje": objekt.zanimanje
    }
    }
 
  const saljiPodatke = event => {
    event.preventDefault();

        const zaSlanje = obradiPodatke(formaPodaci)
        
        axios.post('http://localhost:3001/akcija', zaSlanje)
        .then(rez => {
            props.dodaj((stanje) => [...stanje, rez.data])
            console.log(rez.data);
        })
        postaviPodatke({
          ime: "",
          prezime: "",
          grad:"",
          zanimanje: ""
        });
  };
  function promjenaUlaza(event) {
    const { name, value } = event.target;
    postaviPodatke({ ...formaPodaci, [name]: value });
  }
 
  return (
    <form onSubmit={saljiPodatke}>
      <div>
        <label>
          Ime:
          <input
            type='text'
            name='ime'
            value={formaPodaci.ime}
            onChange={promjenaUlaza}
            required
          />
        </label>
      </div>
      <div>
        <label>
            Prezime:
        <input type='text' name='prezime' value={formaPodaci.prezime}
            onChange={promjenaUlaza} required />
        </label>
        </div>
        <div>
          <label>
            Grad:
              <select
                  name="grad"
                  value={formaPodaci.grad}
                  onChange={promjenaUlaza}
                  required
                >
                <option value="">Odaberite grad</option>
                  {grad.map((grad, index) => (
                <option key={index} value={grad}>{grad}</option>
                  ))}
              </select>
                </label>
        </div>
        <div>
          <label>
            Zanimanje:
              <select
                  name="zanimanje"
                  value={formaPodaci.zanimanje}
                  onChange={promjenaUlaza}
                  required
                >
                <option value="">Odaberite zanimanje</option>
                  {zanimanja.map((zanimanje, index) => (
                <option key={index} value={zanimanje}>{zanimanje}</option>
                  ))}
              </select>
                </label>
        </div>
      <button type='submit'>Novi volonter</button>
    </form>
  );
}
 
export default UnosFormaVolonter;