import { useState } from "react";
import UnosformaVolonterAktivnost from './UnosformaVolonterAktivnost'
import Brisanje from './Brisanje'

function RedakTablice({ rez, promjena, idaktivnost, isAdmin }) {
    const [volonter, postaviVolonter] = useState([]);
    const [detail, setDetail] = useState(false);

    function ShowDetails() {
        if(detail===false)
            setDetail(true);
        else
            setDetail(false)
    }
    if(isAdmin===true){
        return (
            <tr>
                <td>{rez.vrsta}</td>
                <td>{rez.datum}</td>
                <td><Brisanje idaktivnost={rez.id} promjena={promjena}/></td>
                <td><button onClick={ShowDetails}>Detalji</button></td>
                <td>
                    {detail && (
                        <div>
                            <p>ID: {rez.id}</p>
                            <p>Vrsta: {rez.vrsta}</p>
                            <p>Datum: {rez.datum}</p>
                            <p>Vrijeme: {rez.vrijeme}</p>
                            <p>Mjesto: {rez.mjesto}</p>
                            <p>Opis: {rez.opis}</p>
                        </div>
                    )}
                </td>
            </tr>
        );
    }
    else
    return (
        <tr>
            <td>{rez.vrsta}</td>
            <td>{rez.datum}</td>
            <td><button onClick={ShowDetails}>Detalji</button></td>
            <td>
                {detail && (
                    <div>
                        <p>ID: {rez.id}</p>
                        <p>Vrsta: {rez.vrsta}</p>
                        <p>Datum: {rez.datum}</p>
                        <p>Vrijeme: {rez.vrijeme}</p>
                        <p>Mjesto: {rez.mjesto}</p>
                        <p>Opis: {rez.opis}</p>
                    </div>
                )}
            </td>
        </tr>
    );
}

export default RedakTablice;
