
import { useState } from "react";
import RedakTabliceUdruge from "./RedakTabliceUdruge";

function TablicaUdruge({ udruge, postaviPodatke, isAdmin }) {
    const [sortiranoPo, postaviSortiranoPo] = useState(null);

    const sortirajUdruge = (kriterij) => {
        if (sortiranoPo === kriterij) {
            postaviPodatke([...udruge.reverse()]);
        } else {
            let sortedUdruge = [...udruge];
            sortedUdruge.sort((a, b) => {
                return a[kriterij].toLowerCase() > b[kriterij].toLowerCase() ? 1 : -1;
            });
            postaviPodatke(sortedUdruge);
            postaviSortiranoPo(kriterij);
        }
    };

    return (
        <table>
            <thead>
                <tr><th>Pritisnite na naziv za sortiranje: Ime, Adresa ili Grad</th></tr>
                <tr>
                    <th onClick={() => sortirajUdruge('ime')}>Ime</th>
                    <th onClick={() => sortirajUdruge('adresa')}>Adresa</th>
                    <th onClick={() => sortirajUdruge('grad')}>Grad</th>
                </tr>
            </thead>
            <tbody>
                {udruge.map(r => (
                    <RedakTabliceUdruge key={r.id} rez={r} postaviPodatke={postaviPodatke} isAdmin={isAdmin}/>
                ))}
            </tbody>
        </table>
    );
}

export default TablicaUdruge;