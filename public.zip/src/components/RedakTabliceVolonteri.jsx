import { useState } from "react";
import UnosformaVolonter from './UnosFormaVolonter'
import BrisanjeVolontera from './BrisanjeVolonter'
import axios from "axios";


function RedakTabliceVolonter({ rez, prikaz, isAdmin }) {
    const [volonter, postaviVolonter] = useState([]);
    const zanimanja = ["student", "zaposlen", "nezaposlen", "umirovljen"];
    const grad = ["Zagreb", "Split", "Rijeka", "Osijek", "Zadar", "Dubrovik", "Sibenik", "Pula"];

    const handleChangegrad = (e) => {
        const { name, value } = e.target;
        postaviVolonter((prevVol) => prevVol.map((item) => item.id === rez.id ? {...item, [name]: value} : item));
        axios.patch(`http://localhost:3001/volonter/${rez.id}`, {
            grad: value
        })
    };
    
    const handleChangezanimanje = (e) => {
        const { name, value } = e.target;
        postaviVolonter((prevVol) => prevVol.map((item) => item.id === rez.id ? {...item, [name]: value} : item));
        axios.patch(`http://localhost:3001/volonter/${rez.id}`, {
            zanimanje: value
        })
    };



    if(isAdmin){
        if(prikaz==="sve"){
            return (
                <tr>
                    <td>{rez.id}</td>
                    <td>{rez.ime}</td>
                    <td>{rez.prezime}</td>
                    <td>
                        <div>
                            <label>
                            <select
                                name='zanimanje'
                                value={rez.zanimanje}
                                onChange={handleChangezanimanje}
                                required
                                >
                                <option value="">Odaberite zanimanje</option>
                                {zanimanja.map((zanimanje, index) => (
                                <option key={index} value={zanimanje}>{zanimanje}</option>
                                ))}
                            </select>
                            </label>
                        </div>
                    </td>
                    <td>
                        <div>
                            <label>
                            <select
                                name='grad'
                                value={rez.grad}
                                onChange={handleChangegrad}
                                required
                                >
                                <option value="">Odaberite grad</option>
                                {grad.map((zanimanje, index) => (
                                <option key={index} value={zanimanje}>{zanimanje}</option>
                                ))}
                            </select>
                            </label>
                        </div>
                    </td>
                    <td><BrisanjeVolontera promjena={postaviVolonter} idvol={rez.id} /></td>
                </tr>
            );
        }
        if(prikaz===rez.zanimanje){
            return (
                <tr>
                    <td>{rez.id}</td>
                    <td>{rez.ime}</td>
                    <td>{rez.prezime}</td>
                    <td>{rez.zanimanje}</td>
                    <td>{rez.grad}</td>
                    <td><BrisanjeVolontera promjena={postaviVolonter} idvol={rez.id} /></td>
                </tr>
            );
        }
    }
    else{
        if(prikaz==="sve"){
            return (
                <tr>
                    <td>{rez.id}</td>
                    <td>{rez.ime}</td>
                    <td>{rez.prezime}</td>
                    <td>{rez.zanimanje}</td>
                    <td>{rez.grad}</td>
                </tr>
            );
        }
        if(prikaz===rez.zanimanje){
            return (
                <tr>
                    <td>{rez.id}</td>
                    <td>{rez.ime}</td>
                    <td>{rez.prezime}</td>
                    <td>{rez.zanimanje}</td>
                    <td>{rez.grad}</td>
    
                </tr>
            );
        }
    }

}

export default RedakTabliceVolonter;
