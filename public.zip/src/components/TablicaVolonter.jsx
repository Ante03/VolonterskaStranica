import RedakTabliceVolonter from "./RedakTabliceVolonteri";

function TablicaVolonter({ volonteri, prikaz, isAdmin }) {
    return (
        <table>
            <thead>
                <tr>
                <th>ID</th>
                <th>Ime</th>
                <th>Prezime</th>
                <th>Zanimanje</th>
                <th>Grad</th>
                </tr>
            </thead>
            <tbody>
                {volonteri.map(r => (
                <RedakTabliceVolonter key={r.id} rez={r} prikaz={prikaz} isAdmin={isAdmin}/>
                ))}
            </tbody>
        </table>
    );
}

export default TablicaVolonter;
